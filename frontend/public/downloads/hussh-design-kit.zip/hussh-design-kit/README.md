# hussh landing page: design kit

## What's inside
- desktop/ and mobile/: retina (@2x) full-page PNGs plus one PNG per section (1440px and 390px wide layouts).
- assets/images/: every illustration used on the page (mascot, product scenes), full resolution.
- assets/brand-logos/: AI brand logos as SVG (vector, editable). Third-party marks belong to their owners.
- tokens.json: colours, type scale, spacing, radii and button specs.

## Editing in Figma
1. Fully editable layers (recommended): in Figma, open Plugins > search "html.to.design" > paste the live URL
   https://brand-reborn--6k11q143.preview.emergentagent.com > choose Desktop 1440 and Mobile 390. It imports real frames,
   text layers, auto-layout and images that you can edit.
2. Quick mock-ups: drag the PNGs from desktop/ and mobile/ onto a Figma canvas, or drop the SVG logos in as vectors.
3. Fonts: install Plus Jakarta Sans and IBM Plex Mono (both free on Google Fonts) so text layers render correctly.
